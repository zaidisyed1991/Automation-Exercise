import pytest
import os
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities



prefs = {"download.default_directory": os.getcwd() + "/"}

#Chrome options
@pytest.fixture
def chrome_options(chrome_options):
	chrome_options.accept_untrusted_certs = True
	chrome_options.assume_untrusted_cert_issuer = True
	chrome_options.add_argument("--disable-session-crashed-bubble")
	chrome_options.add_argument("--ignore-certificate-errors")
	chrome_options.add_argument('--log-level=3')
	chrome_options.add_argument('no-sandbox')
	chrome_options.add_experimental_option('w3c', False)
	chrome_options.add_experimental_option("prefs", prefs)
	chrome_options.add_argument('--start-maximized')
	chrome_options.set_capability('loggingPrefs', { 'browser':'ALL' })
	return chrome_options


