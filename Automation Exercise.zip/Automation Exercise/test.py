import pytest
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains

    


# LAUNCH LINE: pytest test.py

def test_check_wiki_page(selenium):
	selenium.set_window_size(1920, 1080)
	selenium.get("https://en.wikipedia.org/wiki/Metis_(mythology)")

	# data preparation
	content_block = selenium.find_elements(By.XPATH, '//*[@id="toc"]/ul/li/a')
	
	content_block_filtered_values = []
	for i in content_block:
		content_block_filtered_values.append(i.get_attribute('href'))

	ids_for_checking_of_content_headings = [i.split("#")[1] for i in content_block_filtered_values]


	# checking the headings listed in the `Contents` box are used as headings on the page
	text_of_headers = []
	for item in ids_for_checking_of_content_headings:
		text_of_headers.append(selenium.find_element(By.ID, f"{item}").text)

	get_pure_names_from_ids = [i.text.replace("_", " ")]
	assert get_pure_names_from_ids == get_pure_names_from_ids

	# the headings listed in the `Contents` box have functioning hyperlinks
	for item in ids_for_checking_of_content_headings:
		WebDriverWait(selenium, 10).until(EC.presence_of_element_located((By.ID, f"{item}")))



	#in the _Personified concepts_, `Nike` has a popup that contains the following text:
	#In ancient Greek religion, Nike was a goddess who personified victory. Her Roman equivalent was Victoria.

	nike_xpath = selenium.find_element(By.XPATH, '//*[@id="mw-content-text"]/div[1]/table[1]/tbody/tr[6]/td/div/ul/li[13]/a')

	selenium.execute_script("arguments[0].scrollIntoView(true);", nike_xpath)

	WebDriverWait(selenium, 10).until(EC.element_to_be_clickable((By.XPATH, '//*[@id="mw-content-text"]/div[1]/table[1]/tbody/tr[6]/td/div/ul/li[13]/a')))
	action = ActionChains(selenium)
	action.move_to_element(nike_xpath).perform()
	WebDriverWait(selenium, 10).until(EC.element_to_be_clickable((By.CSS_SELECTOR, ".mwe-popups-extract p")))


	text_from_nike_popup = selenium.find_element_by_css_selector(".mwe-popups-extract p").text
	

	# as result we have assertion fail, because of difference in text
	text_from_task = "In ancient Greek religion, Nike was a goddess who personified victory. Her Roman equivalent was Victoria."
	assert text_from_task == text_from_nike_popup
	

	#in the _Personified concepts_, if you click on `Nike`, it takes you to a page that displays a family tree
	body_for_scroll = selenium.find_element_by_tag_name("body")
	body_for_scroll.send_keys(Keys.HOME)

	WebDriverWait(selenium, 10).until(EC.element_to_be_clickable((By.XPATH, '//*[@id="mw-content-text"]/div[1]/p[1]/a[1]')))
	selenium.execute_script("arguments[0].scrollIntoView(true);", nike_xpath)
	time.sleep(0.5) # for sure to avoid rare errors
	WebDriverWait(selenium, 10).until(EC.element_to_be_clickable((By.XPATH, '//*[@id="mw-content-text"]/div[1]/table[1]/tbody/tr[6]/td/div/ul/li[13]/a'))).click()


	assert selenium.current_url == "https://en.wikipedia.org/wiki/Nike_(mythology)"
	tree_locator = "Family_tree"
	WebDriverWait(selenium, 10).until(EC.presence_of_element_located((By.ID, tree_locator)))
	selenium.execute_script("arguments[0].scrollIntoView(true);", selenium.find_element(By.ID, tree_locator))

	table_data = selenium.find_elements(By.XPATH, '//*[@id="mw-content-text"]/div/table/tbody/tr/td/table/tbody/tr/td')
	filterind_table_data = [i.text for i in table_data if len(i.text) > 1]

	assert len(filterind_table_data) == 29 # total count of names in family tree

